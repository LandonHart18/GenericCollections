﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class Stack
    {
        public void StackMain()
        {
            Stack<int> numbers = new Stack<int>();

            //Fill
            foreach (int number in new int[5] { 19, 18, 17, 16, 15 })
            {
                numbers.Push(number);
            }

            //Iterate
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
