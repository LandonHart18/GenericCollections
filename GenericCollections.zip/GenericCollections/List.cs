﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace GenericCollections
{
    class List
    {
        public void ListMain()
        {
            List<int> numbers = new List<int>();

            //Fill
            foreach (int number in new int[5] { 1, 2, 3, 4, 5 })
            {
                numbers.Add(number);
            }

            //Iterate
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
        }
        
    }
}
