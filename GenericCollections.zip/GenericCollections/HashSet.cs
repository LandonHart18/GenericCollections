﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class HashSet
    {
        public void HashSetMain()
        {
            HashSet<string> names = new HashSet<string>( new string[] {"Landon", "Harry", "Berry", "Jerry", "Larry"});

            foreach (string name in names)
            {
                Console.WriteLine(name);
            }
        }
    }
}
