﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class Queue
    {
        public void QueueMain()
        {
            Queue<int> numbers = new Queue<int>();

            //Fill
            foreach (int number in new int[5] { 10, 11, 12, 13, 14 })
            {
                numbers.Enqueue(number);
            }

            //Iterate
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
