﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class LinkedList
    {
        public void LinkedListMain()
        {
            LinkedList<int> numbers = new LinkedList<int>();

            //Fill
            foreach (int number in new int[5] { 9, 8, 7, 6, 5 })
            {
                numbers.AddFirst(number);
            }

            //Iterate
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
