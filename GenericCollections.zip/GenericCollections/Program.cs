﻿using System;
using System.Threading.Channels;

namespace GenericCollections
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("\t\t\t\t\t\tGENERIC CLASSES\n------------------------------------------------------------------------------------------------------------------------");
            //Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("Please select one of the following:\n\n1. List Collection\n2. LinkedList Collection\n3. Queue Collection\n4. Stack Collection\n5. Dictionary Collection\n" +
                              "6. SortedList Collection\n7. HashSet Collection\n8. Exit Program");
            int caseSwitch = Int32.Parse(Console.ReadLine());

            switch (caseSwitch)
            {
                case 1:
                    Console.WriteLine("Printing from the List Collection!");
                    List list = new List();
                    list.ListMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 2:
                    Console.WriteLine("Printing from the LinkedList Collection!");
                    LinkedList linkedList = new LinkedList();
                    linkedList.LinkedListMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 3:
                    Console.WriteLine("Printing from the Queue Collection!");
                    Queue queue = new Queue();
                    queue.QueueMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 4:
                    Console.WriteLine("Printing from the Stack Collection!");
                    Stack stack = new Stack();
                    stack.StackMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 5:
                    Console.WriteLine("Printing from the Dictionary Collection!");
                    Dictionary dictionary = new Dictionary();
                    dictionary.DictionaryMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 6:
                    Console.WriteLine("Printing from the SortedList Collection!");
                    SortedList sortedList = new SortedList();
                    sortedList.SortedListMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 7:
                    Console.WriteLine("Printing from the HashSet Collection!");
                    HashSet hashSet = new HashSet();
                    hashSet.HashSetMain();
                    Console.WriteLine("\nReturning to the Main Menu to select a new collection or exit the program!\n\n");
                    Main();
                    break;
                case 8:
                    Console.WriteLine("Ending program.");
                    break;
            }
        }
    }
}
