﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class SortedList
    {
        public void SortedListMain()
        {
            SortedList<string, int> ages = new SortedList<string, int>();

            //Fill
            ages.Add("Landon", 23);
            ages.Add("Harry", 45);
            ages.Add("Jerry", 112);
            ages.Add("Berry", 34);
            ages.Add("Larry", 23);

            //Iterate
            foreach (KeyValuePair<string, int> element in ages)
            {
                string name = element.Key;
                int age = element.Value;
                Console.WriteLine($"Name: {name}, Age: {age}");
            }
        }
    }
}
