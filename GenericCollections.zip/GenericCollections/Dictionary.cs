﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCollections
{
    class Dictionary
    {
        public void DictionaryMain()
        {
            Dictionary<string, int> ages = new Dictionary<string, int>();

            //Fill
            ages.Add("Blain", 67);
            ages.Add("Chain", 54);
            ages.Add("Bain", 22);
            ages.Add("Lain", 43);
            ages.Add("Cain", 32);

            //Iterate
            foreach (KeyValuePair<string, int> element in ages)
            {
                string name = element.Key;
                int age = element.Value;
                Console.WriteLine($"Name: {name}, Age: {age}");
            }
        }
    }
}
